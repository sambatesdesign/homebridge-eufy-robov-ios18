import { API, AccessoryPlugin, Logging, HAP, AccessoryConfig, Service, CharacteristicValue, CharacteristicSetCallback, CharacteristicGetCallback } from 'homebridge';
import TuyAPI from 'tuyapi';

let hap: HAP;

export = (api: API) => {
  hap = api.hap;
  api.registerAccessory('homebridge-eufy-minimal', 'EufyRoboVac', EufyRoboVacAccessory);
};

function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

class EufyRoboVacAccessory implements AccessoryPlugin {
  private readonly log: Logging;
  private readonly name: string;
  private readonly config: { id: string; key: string; ip?: string };
  private readonly service: Service;
  private readonly informationService: Service;
  private device: TuyAPI;

  constructor(log: Logging, config: AccessoryConfig) {
    this.log = log;
    this.name = config.name;
    this.config = {
      id: config.deviceId,
      key: config.localKey,
      ip: config.ip
    };

    this.device = new TuyAPI({
      id: this.config.id,
      key: this.config.key,
      ip: this.config.ip,
      issueRefreshOnConnect: true
    });

    this.service = new hap.Service.VacuumCleaner(this.name);
    this.service.getCharacteristic(hap.Characteristic.Active)
      .on(hap.CharacteristicEventTypes.GET, this.handleGetActive.bind(this))
      .on(hap.CharacteristicEventTypes.SET, this.handleSetActive.bind(this));

    this.informationService = new hap.Service.AccessoryInformation()
      .setCharacteristic(hap.Characteristic.Manufacturer, 'Eufy')
      .setCharacteristic(hap.Characteristic.Model, 'RoboVac');

    this.log.info(`${this.name} accessory created.`);
  }

  async connect(): Promise<void> {
    if (!this.device.isConnected()) {
      this.log.debug('Finding and connecting to RoboVac...');
      await this.device.find();
      await this.device.connect();
    }
  }

  async handleGetActive(callback: CharacteristicGetCallback) {
    try {
      callback(null, hap.Characteristic.Active.INACTIVE);
    } catch (error) {
      this.log.error('Failed to get Active state:', error);
      callback(error as Error);
    }
  }

  async handleSetActive(value: CharacteristicValue, callback: CharacteristicSetCallback) {
    try {
      await this.connect();
      if (value === hap.Characteristic.Active.ACTIVE) {
        this.log.info('Sending start cleaning command...');
        await this.device.set({ dps: 1, set: true });
        await this.device.set({ dps: 2, set: true });
        await this.device.set({ dps: 5, set: 'auto' });
        await this.device.set({ dps: 122, set: 'Continue' });
      } else {
        this.log.info('Sending stop and dock command...');
        await this.device.set({ dps: 2, set: false });
        await this.device.set({ dps: 101, set: true });
      }
      callback();
    } catch (error) {
      this.log.error('Error in setActive:', error);
      callback(error as Error);
    }
  }

  identify(): void {
    this.log('Identify requested');
  }

  getServices(): Service[] {
    return [this.informationService, this.service];
  }
}
